package io.github.starmage27.testtask4workmate.data

data class Info(
    val count: Int,
    val next: String?,
    val pages: Int,
    val prev: String?
)