package io.github.starmage27.testtask4workmate.data.character

data class CharacterLocation(
    val name: String,
    val url: String
)